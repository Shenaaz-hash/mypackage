# mypackage

This library was created as an example of how to publish you own python package

# How to install
...
